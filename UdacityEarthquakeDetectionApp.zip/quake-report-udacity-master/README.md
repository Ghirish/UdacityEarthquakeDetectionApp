# Quake Report App

This app displays a list of recent earthquakes in the world from the U.S. Geological Survey (USGS) organization. Made under Udacity's _Android Basics: Networking_ course (Android Basics Nanodegree).

More info on the USGS Earthquake API available at: https://earthquake.usgs.gov/fdsnws/event/1/
